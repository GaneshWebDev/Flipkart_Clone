import './login.css'
import { useState } from 'react';
import { useForm } from 'react-hook-form';
function Login(fun){
    const [registerDiv,setRegister]=useState(false);
    const {register,handleSubmit,getValues,reset,formState:{errors}}=useForm()
    const logFun = (data) => {
        console.log(data);
        reset(); // Use the reset function from React Hook Form
      }
    return(
        <div className="login">
            <div className="div1">
                <div className='title'>
                <h1>Login</h1>
                <span>Ge access to your</span>
                <span>Orders, Wishlist and</span>
                <span>Recommendations</span>
                </div>
                <div>
                   <img src="https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcTgAY-2BpgFSnNeLLyPfok-5gyEyyBW1qHLbG9BZOc_lQBYpEgy"/>
                </div>
            </div>
            <div className="div2">
            <i class="fa-solid fa-xmark" onClick={()=>fun.loginFun(false)}></i>
            <form id='login' onSubmit={handleSubmit(()=>logFun())}>
                <div className='divHold'>
                
                    <div className='input'>
                        <div className='inputDiv'><input type={"text" || "email"} {...register('email',{required:true})} placeholder="Enter Email/Mobile number" id='email'/></div>
                        {errors?.email&&<p>Email Required</p>}
                        <div className='inputDiv'><input type='password' {...register('password',{required:true,minLength:{value:8,message:"Password must have at least 8 characters"}})} placeholder="Enter Password" required/>{!registerDiv&&<p>Forgot?</p>}</div>
                        {errors?.password&&<p>{errors.password.message}</p>}
                        {registerDiv&&<div className='inputDiv bottomInput'><input type='password' placeholder="Confirm Password" {...register('confirmPassword',{validate:value=>{
                        const password=getValues("password");
                        return value===password || "password didnot match"
                    }})}/></div>}
                    </div>
                    {!registerDiv&&<p>By counting, you agree to Flipkart's <span>Terms of Use and Privacy Ploicy.</span></p>}
                    <div className='btns'>
                    <button id="login" type='submit'>{registerDiv?'Register':'Login'}</button>
                    {!registerDiv&&<span>OR</span>}
                    {registerDiv&&<button id='reset' onClick={()=>setRegister(false)}>Existing User? Log in</button>}
                    {!registerDiv&&<button id='reset'>Request OTP</button>}
                    {!registerDiv&&<p className='register'>New to Flipkart? <span onClick={()=>setRegister(true)}>Create an account</span></p>}
                    </div>
            
                </div>
                </form>
            </div>
        </div>
    )
}
export default Login;