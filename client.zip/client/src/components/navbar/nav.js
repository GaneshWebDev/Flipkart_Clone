import './nav.css';
import { useState } from 'react';
function Nav(loginFun){
  const [open,setOpen]=useState(false);
  console.log(loginFun,'login');
    return(
        <>
          <div className='navbar'>
            <div className='disDiv'>
            <div className='logo_div'>
              <img src='https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/flipkart-plus_8d85f4.png' className='logo'/>
              <p><span id='logo_text_1'>Explore</span>&nbsp;<span  id='logo_text_2'> Plus</span><img src='https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/plus_aef861.png'/></p>
            </div>
            <div className='search_elements'>
                <input type='text' placeholder='   Serach for products, brands and more' className='searchBox'/>
                <i class="fa-solid fa-magnifying-glass searchIcon"></i>
            </div>
              <ul>
                <li><button className='login_btn' onClick={()=>loginFun.loginFun(true)}>Login</button></li>
                <li><button className='btn'>Become a Seller</button></li>
                <li><button className='btn'>More</button></li>
                <li><div className='cart'>
                <i class="fa-solid fa-cart-shopping"></i>
                  <button className='btn'>Cart</button>
                </div>
                </li>
              </ul>
            </div>

          </div>
        </>
    )
}
export default Nav;