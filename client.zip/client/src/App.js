import './App.css'
import Nav from './components/navbar/nav';
import Home from './screens/homeScreen/home';
import Products from './screens/productsScreen/products';
import {  Routes, Route, useNavigate} from 'react-router-dom'
import {useSelector,} from 'react-redux/es/hooks/useSelector';
import Login from './screens/loginScreen/login';
import { useState } from 'react';
function App() {
  const state=useSelector(state=>state);
  const user=state.userSlice.user;
  console.log(state);
  const [login,setLogin]=useState(false);
  console.log(login)
  return (
    <div className='app'>
          <Nav loginFun={setLogin}/>
        <Routes>
            <Route path='/' element={user?<Products/>:<Home login={login} loginFun={setLogin}/>}/>
        </Routes>
    </div>
  )
}

export default App
